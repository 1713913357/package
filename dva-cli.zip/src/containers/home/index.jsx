import React, { Component } from 'react'

class HomePage extends Component {
    render() {
        return <div>
            this is homepage
        </div>
    }
}

export default HomePage;