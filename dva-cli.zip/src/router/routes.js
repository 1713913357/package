import Home from '@/containers/home';

export default [{
    path: '/home',
    name: 'home',
    component: Home,
    children: []
}]