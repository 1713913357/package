export default {
    namespace: 'login',
    state: {
        token: "123321"
    }
}