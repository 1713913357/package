export default {
    namespace: 'music',
    state: {
        token: "123321"
    }
}