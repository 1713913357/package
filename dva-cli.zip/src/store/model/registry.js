export default {
    namespace: 'registry',
    state: {
        token: "123321"
    }
}