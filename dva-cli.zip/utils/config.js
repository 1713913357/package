export const responseText = {
    401: {
        type: "error",
        message: "没有权限"
    },
    500: {
        type: "error",
        message: "服务器错误！"
    }
}