exports.mysql = {
    enable: true,
    package: 'egg-mysql'
}
exports.validate = {
    enable: true,
    package: 'egg-validate'
}

exports.alinode = {
    enable: true,
    package: 'egg-alinode',
};