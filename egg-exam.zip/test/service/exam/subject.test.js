const {app} = require('egg-mock/bootstrap');
const assert = require('assert');
describe('test/service/exam/subject.test.js',()=>{
    // it('subject表中插入数据',async ()=>{
    //     const ctx = app.mockContext();
    //     let subject_texts = ['模块化开发','移动端开发','node基础','组件化开发(vue)','渐进式开发(react)','项目实战','javaScript高级','node高级'];

    //     for(let subject_text of subject_texts){
    //         await ctx.service.exam.subject.createSubject(subject_text);
    //     }

    //     assert(true);
    // })
})