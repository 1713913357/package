const {app} = require('egg-mock/bootstrap');
const assert = require('assert');
describe('test/service/manger/manger.test.js',()=>{
    describe('delGradeRoomStudent',async ()=>{
        // it('删除教室号',async ()=>{
        //     const ctx = app.mockContext();
        //     let result = await ctx.service.manger.manger.delGradeRoomStudent('room','room_id','sli169-rq4rw-llvf3h-izacvv');
        //     console.log(`result:${result}`);
        //     assert(true);
        // });
        // it('删除班级',async ()=>{
        //     const ctx = app.mockContext();
        //     let result = await ctx.service.manger.manger.delGradeRoomStudent('grade','grade_id','37m2mi-3ggaxx-yep28s-wndr6');
        //     console.log(`result:${result}`);
        //     assert(true);
        // })
    })
    
})